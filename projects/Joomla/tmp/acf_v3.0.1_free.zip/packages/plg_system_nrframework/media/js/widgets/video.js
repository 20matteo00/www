var TF_Video=function(){function e(e){this.video=e,this.videoElement=this.video.querySelector(".tf-video-embed"),this.dataset=this.videoElement.dataset,this.overlay=this.video.querySelector(".tf-video-embed-overlay"),this.player=null}return e.prototype.setAttributeBool=function(e,t){return e[t]&&"true"===e[t]?1:0},e}();

